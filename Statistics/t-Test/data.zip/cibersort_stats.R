# The point of this file is to do multiple t.test/ANOVA on
# Cibersort populations to see if they are significantly 
# different in bulk samples

# Set the directory to your file
setwd("/SRA_store/shared/repo/disco/sc_resources/in_house_datasets/D21_09/scripts")
library(tidyverse)
library(rstatix)
library(ggpubr)
library(crch)
source('header.R')


# ==================================== START =================================

###
# Reading in cibersort and bulk data for Peng et al
###
path.peng.cibersort <- paste0("./figures/meta/cybersort/Peng/",Sys.Date())

csx <- read.table(file='./intermediate_misc/cibersort/CIBERSORTx_Job16_Results.csv', sep=',', header=T); csx[1:5,1:5]
csx$ID <- sapply(strsplit(csx$Mixture, "_"), FUN=function(x) {paste0("V",x[2])})
csx[1:5,'ID']
  
bulk.meta <- read.xlsx('./intermediate_misc/cibersort/D21-09_RNA-Seq.xlsx', colNames = T); head(bulk.meta)
bulk.meta <- rename(bulk.meta, X1="exp.assay")
bulk.meta$`Heart.Bulk.RNA-seq` <- NULL
head(bulk.meta)


bulk.meta[match(csx[,'ID'], bulk.meta[,"ID"]),]
# Final cibersort object with meta data attached.
csx <- cbind(csx, bulk.meta[match(csx[,'ID'], bulk.meta[,"ID"]),c('exp.assay', "Nppb", "Col3a1")])


data.ciber <- gather(csx, cell.type, abund, CM:BC, factor_key=TRUE)
head(data.ciber)
palette.ciber <- unique(data.ciber$cell.type)
names(palette.ciber) <- glasbey(length(unique(data.ciber$cell.type)))

data.ciber <- data.ciber %>% dplyr::group_by(Mixture) %>% dplyr::mutate(percent = prop.table(abund) * 100) %>% ungroup() 
plot.cibersort <- ggplot(data.ciber, aes(fill=cell.type, x=ID, y=percent)) + 
  geom_bar(position="fill",stat='identity') + theme_bw() +
  scale_fill_manual(values = names(palette.ciber)) + 
  geom_text(aes(label = round(percent, 3)),
            colour='#FFFFFF', size = 4, angle = 90,
            position = position_fill(vjust = 0.5)) +
  facet_grid(~exp.assay, scales="free_x") +
  theme(axis.text.x = element_text(angle = 40, vjust = 1, hjust=1, lineheight = 0.75, size = 11),
        axis.text.y = element_text(family = "Arial", size = 10, face = "plain", color = "black"),
        plot.title = element_text(hjust = 0.5),
        legend.text = element_text(family = "Arial", size = 12, face = "plain", color = "black"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank());plot.cibersort
ggsave("Peng_bulk_deconv_meta.png",plot = plot.cibersort,
       path = path.peng.cibersort, width = 13, height = 9, 
       units = 'in', )

###
# End of reading in cibersort and bulk data for Peng et al
###

###
# Playing with Stats
###
cell.types <- c("CM", "EC", "FB", "PC.SMC", "Epi", "BC")
data.stats <- csx[, c("ID", cell.types,"exp.assay")]; head(data.stats)

data.stats %>%
  group_by(exp.assay) %>% 
  summarise(mean = mean(CM), spread = sd(CM))
#  exp.assay     mean spread
# <chr>        <dbl>  <dbl>
# 1 Control       439.  142. 
# 2 HFpEF-SGLT2   518.  275. 
# 3 HFpEF-TYA018  434.   76.2
# 4 HFpEF-Veh     435.  212.

data.stats %>% anova_test(CM ~ exp.assay)
# ANOVA Table (type II tests)
# 
#      Effect DFn DFd     F     p p<.05   ges
# 1 exp.assay   3  34 0.479 0.699       0.041

data.stats %>%
  pairwise_t_test(CM ~ exp.assay, p.adjust.method = "bonferroni")
#   .y.   group1       group2          n1    n2     p p.signif p.adj p.adj.signif
# * <chr> <chr>        <chr>        <int> <int> <dbl> <chr>    <dbl> <chr>       
# 1 CM    Control      HFpEF-SGLT2      8    11 0.383 ns           1 ns          
# 2 CM    Control      HFpEF-TYA018     8    11 0.955 ns           1 ns          
# 3 CM    HFpEF-SGLT2  HFpEF-TYA018    11    11 0.313 ns           1 ns          
# 4 CM    Control      HFpEF-Veh        8     8 0.965 ns           1 ns          
# 5 CM    HFpEF-SGLT2  HFpEF-Veh       11     8 0.358 ns           1 ns          
# 6 CM    HFpEF-TYA018 HFpEF-Veh       11     8 0.994 ns           1 ns

data.stats %>%
  t_test(CM ~ exp.assay, comparisons = list(c('HFpEF-Veh', "Control")))
#   .y.   group1  group2       n1    n2 statistic    df     p p.adj p.adj.signif
# * <chr> <chr>   <chr>     <int> <int>     <dbl> <dbl> <dbl> <dbl> <chr>       
# 1 CM    Control HFpEF-Veh     8     8    0.0479  12.2 0.963 0.963 ns 


# The above format only works for 1 item
# we need a group by to work on multiple
# categories and this is how I will do it
data.stats <- data.ciber[,c("ID", "cell.type","abund", "percent","exp.assay")]; head(data.stats)
stat.test <- data.stats %>%
  group_by(cell.type) %>%
  t_test(formula =percent ~ exp.assay, comparisons = list(c('HFpEF-Veh', "Control"))); stat.test

# Add statistical test p-values
stat.test <- stat.test %>% add_xy_position(x = "exp.assay")
stat.test$xmax <- rep(2, dim(stat.test)[1])

# Plotting it from https://www.datanovia.com/en/blog/how-to-perform-multiple-t-test-in-r-for-different-variables/
plot.bulk.diff <- ggboxplot(
  data.stats, x = "exp.assay", y = "percent",
  fill = "exp.assay", palette = "npg", legend = "none",
  ggtheme = theme_pubr(border = TRUE)
) +
  stat_pvalue_manual(stat.test, label = "p.adj.signif") +
  facet_wrap(~cell.type, scale='free') + 
  theme(axis.text.x = element_text(angle = 40, vjust = 1, hjust=1, lineheight = 0.75, size = 11)); plot.bulk.diff


###
# End of playing with Stats
###

###
# Manually doing a t.test to understand
###
# Formula for a t.test
# (mu1 - mu2) / sqrt(S1/n1 + S2/n2)
# Question: Is HFpEF CM proportion different from Control?

data.stats <- data.ciber[,c("ID", "cell.type","abund", "percent","exp.assay")]; head(data.stats)
data.stats %>%
  group_by(cell.type, exp.assay) %>% 
  summarise(mean = mean(percent), SD = sd(percent))
#   cell.type exp.assay     mean   SD
#   <fct>     <chr>        <dbl>  <dbl>
# 1 CM        Control      53.0   8.42 
# 2 CM        HFpEF-SGLT2  53.8  11.0  
# 3 CM        HFpEF-TYA018 55.4   5.55 
# 4 CM        HFpEF-Veh    48.1   6.63 

t.score <- (53 - 48.1) / sqrt(8.42^2/8 + 6.63^2/8); t.score
# [1] 1.293211

# Need around 2.4 to be considered significant
# We essentially have a Z-score of 1.29, so lets calculate
# the probability we got this by chance.
2*pt(t.score, 7, lower.tail=F)
# [1] 0.2347678


# Now calculated by the computer
data.stats %>%
  group_by(cell.type) %>%
  t_test(formula =percent ~ exp.assay, comparisons = list(c('HFpEF-Veh', "Control")))
#   cell.type .y.     group1  group2       n1    n2 statistic    df     p p.adj p.adj.signif
# 1 CM        percent Control HFpEF-Veh     8     8     1.30  13.3  0.216 0.216 ns 

# Very strange that my two values are different! t_test seems to be 
# doing some under the hood magic, but it does seem pretty close. 
# It is doing a 2 tailed test


data.stats %>%
  group_by(cell.type) %>%
  wilcox_test(formula=percent ~ exp.assay, comparisons = list(c('HFpEF-Veh', "Control")))


###
# End of manually doing a t.test to understand
###